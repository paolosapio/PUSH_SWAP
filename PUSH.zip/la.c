#include "push_swap.h"

bool la(t_stack *stack)
{
	print_list(stack->a);
	return true;
}
