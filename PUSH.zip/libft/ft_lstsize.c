#include "libft.h"

int ft_lstsize(t_list *list)
{
	int i;

	i = 0;
	while(list)
	{
		list = list->next;
		++i;
	}
	return(i);
}
