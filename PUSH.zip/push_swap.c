#include "push_swap.h"

int push_swap(t_stack *stack)
{
	(void)stack;

	stack->must_print = true;
	printf("hello from PS\n");
	return (0);
}
