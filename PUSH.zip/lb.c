#include "push_swap.h"

bool lb(t_stack *stack)
{
	print_list(stack->b);
	return (true);
}
